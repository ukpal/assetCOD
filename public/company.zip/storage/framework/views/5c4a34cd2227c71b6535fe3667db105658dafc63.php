<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    
    
    
<section class="content">
      <div class="container-fluid">
        
      </div>
    </section>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('Administrator.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/c2marketplace/aditya-birla-group.c2marketplace.com/resources/views/Administrator/dashboard/index.blade.php ENDPATH**/ ?>