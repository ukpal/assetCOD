<?php $__env->startSection('content'); ?>

<style>
    input {
        padding: 0;
        height: initial;
        width: initial;
        margin-bottom: 0;
        display: none;
        cursor: pointer;
    }

    label {
        position: relative;
        cursor: pointer;
    }

    label:before {
        content: '';
        -webkit-appearance: none;
        background-color: #fff;
        border: 2px solid #838383;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), inset 0px -15px 10px -12px rgba(0, 0, 0, 0.05);
        padding: 8px;
        display: inline-block;
        position: relative;
        vertical-align: middle;
        cursor: pointer;
        margin-right: 5px;
    }

    input:checked+label:after {
        content: '';
        display: block;
        position: absolute;
        top: 6px;
        left: 8px;
        width: 6px;
        height: 10px;
        border: solid #0079bf;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
    }

    input:checked+label:before {
        border: 2px solid #838383;
        background-color: #fff;
    }

    input:disabled+label:before {
        border: 2px solid #c3c3c3;
        background-color: #c3c3c3;
    }
</style>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Modules available</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Modules</li>
                        
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <!-- <h3 class="card-title"></h3> -->
                            <div class="row mx-0 justify-content-between ">
                                <div class="col-md-2 d-flex align-items-stretch">
                                </div>
                                <div class="col-md-5 d-flex align-items-stretch ">
                                    <?php echo $__env->make('Administrator.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="modules" class="table table-bordered table-hover">
                                <thead class="bg-secondary">
                                    <tr>
                                        <th style="width: 46px">Sl. No.</th>
                                        <th>Module Name</th>
                                        <th>View</th>
                                        <th>Add</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count =1; ?>
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($count++); ?></td>
                                        <td><?php echo e($module->name); ?></td>
                                        <td>
                                            <input id="a<?php echo e($module->m_id); ?>" type="checkbox" onclick="return false"
                                                <?php echo e(($module->view==-1) ? 'disabled': 'checked'); ?>>
                                            <label for="a<?php echo e($module->m_id); ?>"></label>
                                        </td>
                                        <td>
                                            <input id="b<?php echo e($module->m_id); ?>" type="checkbox" onclick="return false"
                                                <?php echo e(($module->add==-1) ? 'disabled': 'checked'); ?>>
                                            <label for="b<?php echo e($module->m_id); ?>"></label>
                                        </td>
                                        <td>
                                            <input id="c<?php echo e($module->m_id); ?>" type="checkbox" onclick="return false"
                                                <?php echo e(($module->edit==-1) ? 'disabled': 'checked'); ?>>
                                            <label for="c<?php echo e($module->m_id); ?>"></label>
                                        </td>
                                        <td>
                                            <input id="d<?php echo e($module->m_id); ?>" type="checkbox" onclick="return false"
                                                <?php echo e(($module->delete==-1) ? 'disabled': 'checked'); ?>>
                                            <label for="d<?php echo e($module->m_id); ?>"></label>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Administrator.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/c2marketplace/aditya-birla-group.c2marketplace.com/resources/views/Administrator/Modules/index.blade.php ENDPATH**/ ?>