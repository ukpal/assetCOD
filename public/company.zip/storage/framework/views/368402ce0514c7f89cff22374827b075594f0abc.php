<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AssetCOD | Login</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/Administrator/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/Administrator/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/Administrator/dist/css/adminlte.min.css')); ?>">
</head>

<body class="hold-transition login-page">
    <div class="login-box">


        <div class="login-logo">
            <img id="company-logo" class="d-none" src="" width="40%" alt="" style="border-radius:50%">
            <img id="default-logo" class="d-none" src="<?php echo e(URL::asset('public/Administrator/dist/img/logo.png')); ?>" width="40%" alt="">
        </div>


        <div class="card">
            <div class="col-md-5 d-flex align-items-stretch ">
                <?php echo $__env->make('Administrator.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>

                <form action="<?php echo e(route('postLogin')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Email">
                        <div class="input-group-append">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" data-error='email'><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Password">
                        <div class="input-group-append">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger" data-error='password'><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('public/Administrator/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(URL::asset('public/Administrator/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(URL::asset('public/Administrator/dist/js/adminlte.min.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('public/Administrator/plugins/alphanum/jquery.alphanum.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('public/Administrator/plugins/toastr/toastr.min.js')); ?>"></script>

    <script>
        setTimeout(function() {
            $('.toast').fadeOut();
        }, 4000);
        
    </script>

    <script type="text/javascript">
        $(function() {
            if (localStorage.getItem('company_logo')) {
                $('#company-logo').attr("src", "<?php echo e(url('/public')); ?>"+"/Administrator/images/logo/" + localStorage.getItem('company_logo'));
                $('#company-logo').removeClass('d-none');
            }else{
                $('#default-logo').removeClass('d-none');
            }

            $("[name='email']").on("focus", function() {
                // $(this).alpha();
                $("[data-error='email']").html("");
                $(this).removeClass("is-invalid");
            });
            $("[name='password']").on("focus", function() {
                // $(this).numeric();
                $("[data-error='password']").html("");
                $(this).removeClass("is-invalid");
            });
            // $("[name='code']").on("focus", function() {
            //     // $(this).numeric();
            //     $("[data-error='code']").html("");
            //     $(this).removeClass("is-invalid");
            // });
        });
    </script>
</body>

</html>
<?php /**PATH /home2/c2marketplace/aditya-birla-group.c2marketplace.com/resources/views/Administrator/login.blade.php ENDPATH**/ ?>