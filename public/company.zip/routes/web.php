<?php

use App\Http\Controllers\Administrator\AuthController;
use App\Http\Controllers\Administrator\HomeController;
use App\Http\Controllers\Administrator\ModuleController;
use App\Http\Controllers\Administrator\ModulePermissionController;
use App\Http\Controllers\Administrator\RoleController;
use App\Http\Controllers\Administrator\SettingController;
use App\Http\Controllers\Administrator\SubscriptionController;
use App\Http\Controllers\Administrator\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::redirect('/', 'admin/dashboard');
Route::redirect('/login', 'admin/login')->name('login');

Route::group(['middleware' =>  ['checkAuth','dynamicDB','checkCompanyStatus'],'prefix'=>'admin'], function () {
    Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');
    // Route::get('/get-modulepermission/{id}', [ModulePermissionController::class, 'getModulePermissions'])->name('get-modulepermission');
    // Route::post('/set-modulepermission', [ModulePermissionController::class, 'setModulePermission'])->name('set-modulepermission');
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');


    Route::prefix('modules')->group(function () {
        Route::controller(ModuleController::class)->group(function () {
            Route::get('/', 'modules')->name('modules');
            // Route::get('/create', 'createModule')->name('create.module');
            // Route::post('/store', 'storeModule')->name('store.module');
            // Route::get('/edit/{module}', 'editModule')->name('edit.module');
            // Route::post('/update/{module}', 'updateModule')->name('update.module');
            // Route::get('/delete/{id}', 'deleteModule')->name('delete.module');
            Route::get('/status/update', 'statusUpdate')->name('update.status');
        });
    });

    Route::prefix('subscription')->group(function () {
        Route::controller(SubscriptionController::class)->group(function () {
            Route::get('/', 'subscriptions')->name('subscription');
            // Route::get('/new', 'createSubscription');
            // Route::post('/store', 'storeSubscription');
            // Route::get('/edit/{subscription}', 'editSubscription');
            // Route::post('/update/{subscription_id}', 'updateSubscription');
            // Route::get('/status/update', 'statusUpdate')->name('subscription.update.status');
        });
    });

    Route::prefix('settings')->group(function () {
        Route::controller(SettingController::class)->group(function () {
            Route::get('/', 'index')->name('settings');
            Route::get('/get-general-setting', 'getAjaxData')->name('get-general-setting');
            // Route::get('/create', 'createSetting')->name('create.setting');
            // Route::post('/store', 'storeThemeSetting')->name('store.theme.setting');
            Route::get('/edit', 'editSetting')->name('edit.setting');
            Route::post('/update', 'updateSetting')->name('update.setting');
        });
    });

    Route::prefix('roles')->group(function () {
        Route::controller(RoleController::class)->group(function () {
            Route::get('/', 'index')->name('roles');
            Route::get('/create', 'createRole')->name('create.role');
            Route::post('/store', 'storeRole')->name('store.role');
            Route::get('/edit/{role}', 'editRole')->name('edit.role');
            Route::post('/update/{role}', 'updateRole')->name('update.role');
        });
    });

    Route::prefix('users')->group(function () {
        Route::controller(UserController::class)->group(function () {
            Route::get('/', 'index')->name('users');
            Route::get('/status/update', 'statusUpdate')->name('users.update.status');
            Route::get('/create', 'createUser')->name('create.user');
            Route::post('/store', 'storeUser')->name('store.user');
            Route::get('/edit/{id}', 'edituser')->name('edit.user');
            Route::post('/update/{id}', 'updateUser')->name('update.user');
            Route::post('/delete/{id}', 'deleteUser')->name('delete.user');
        });
    });

    Route::get('role-permission/{role_id}',[RoleController::class, 'getPermissions'])->name('role.permission');
    Route::post('set-role-permission',[RoleController::class, 'setPermissions']);
});



Route::prefix('admin')->group(function () {
    Route::get('/login', [AuthController::class, 'login'])->name('admin.login');
    Route::post('/postlogin', [AuthController::class, 'postLogin'])->name('postLogin');
    // Route::get('/create_subdomain', [HomeController::class, 'createSudomain'])->name('create.subdomain');
    // Route::get('/unzip', [HomeController::class, 'unzip'])->name('unzip');
});

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
