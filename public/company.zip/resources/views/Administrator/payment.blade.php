<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <form action="" method="POST">
        <input type="email" name="email" value="" placeholder="">
        <input type="text" name="fname" value="" placeholder="">
        <input type="text" name="lname" value="" placeholder="">
        <input type="text" name="address" value="" placeholder="">
        <input type="text" name="city" value="" placeholder="">
        <input type="text" name="country" value="" placeholder="">
        <input type="text" name="zip" value="" placeholder="">
        <input type="text" name="state" value="" placeholder="">
        <input type="text" name="phone" value="" placeholder="">
        <input type="text" name="ccnum" value="" placeholder="">
        <input type="text" name="credit_card_type" value="" placeholder="">
        <input type="text" name="ccmo" value="" placeholder="">
        <input type="text" name="ccyr" value="" placeholder="">
        <input type="text" name="cvv2_number" value="" placeholder="">
        <input type="text" name="cvv2_number" value="" placeholder="">
        <input type="text" name="cvv2_number" value="" placeholder="">
        <input type="text" name="cvv2_number" value="" placeholder="">
    </form>
</head>
<body>

</body>
</html>
